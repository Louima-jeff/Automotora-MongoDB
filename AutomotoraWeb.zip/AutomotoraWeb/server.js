
const express = require("express");
const { MongoClient, ObjectId } = require("mongodb");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

const client = new MongoClient("mongodb://127.0.0.1:27017");

const configuracion = {
  clientes: ["nombre", "telefono", "ciudad", "estado"],
  vehiculos: ["marca", "modelo", "anio", "precio", "estado"],
  ventas: ["cliente", "vehiculo", "fecha", "monto"],
  pagos: ["venta", "monto", "fecha", "metodo"]
};

async function iniciar() {
  await client.connect();

  const db = client.db("automotora_nosql");

  console.log("MongoDB conectado correctamente");

  for (const [modulo, campos] of Object.entries(configuracion)) {
    const coleccion = db.collection(modulo);
    const ruta = `/api/${modulo}`;

    // CONSULTAR
    app.get(ruta, async (req, res) => {
      try {
        const registros = await coleccion.find().toArray();
        res.json(registros);
      } catch (error) {
        res.status(500).json({
          error: "Error al consultar registros"
        });
      }
    });

    // REGISTRAR
    app.post(ruta, async (req, res) => {
      try {
        const registro = {};

        for (const campo of campos) {
          const valor = req.body[campo];

          if (valor === undefined || valor === null ||
              String(valor).trim() === "") {
            return res.status(400).json({
              error: `El campo ${campo} es obligatorio`
            });
          }

          registro[campo] = String(valor).trim();
        }

        const resultado = await coleccion.insertOne(registro);

        res.status(201).json({
          mensaje: "Registro guardado correctamente",
          _id: resultado.insertedId
        });
      } catch (error) {
        res.status(500).json({
          error: "Error al guardar registro"
        });
      }
    });

    // ACTUALIZAR
    app.put(`${ruta}/:id`, async (req, res) => {
      try {
        const { id } = req.params;

        if (!ObjectId.isValid(id)) {
          return res.status(400).json({
            error: "ID inválido"
          });
        }

        const cambios = {};

        for (const campo of campos) {
          const valor = req.body[campo];

          if (valor === undefined || valor === null ||
              String(valor).trim() === "") {
            return res.status(400).json({
              error: `El campo ${campo} es obligatorio`
            });
          }

          cambios[campo] = String(valor).trim();
        }

        const resultado = await coleccion.updateOne(
          { _id: new ObjectId(id) },
          { $set: cambios }
        );

        if (resultado.matchedCount === 0) {
          return res.status(404).json({
            error: "Registro no encontrado"
          });
        }

        res.json({
          mensaje: "Registro actualizado correctamente"
        });
      } catch (error) {
        res.status(500).json({
          error: "Error al actualizar registro"
        });
      }
    });

    // ELIMINAR
    app.delete(`${ruta}/:id`, async (req, res) => {
      try {
        const { id } = req.params;

        if (!ObjectId.isValid(id)) {
          return res.status(400).json({
            error: "ID inválido"
          });
        }

        const resultado = await coleccion.deleteOne({
          _id: new ObjectId(id)
        });

        if (resultado.deletedCount === 0) {
          return res.status(404).json({
            error: "Registro no encontrado"
          });
        }

        res.json({
          mensaje: "Registro eliminado correctamente"
        });
      } catch (error) {
        res.status(500).json({
          error: "Error al eliminar registro"
        });
      }
    });
  }

  app.listen(3000, "127.0.0.1", () => {
    console.log("Servidor funcionando en http://localhost:3000");
  });
}

iniciar().catch(error => {
  console.error("Error al conectar MongoDB:", error);
  process.exit(1);
});
